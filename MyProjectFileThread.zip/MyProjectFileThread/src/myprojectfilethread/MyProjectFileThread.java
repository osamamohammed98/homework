
package myprojectfilethread;

public class MyProjectFileThread {

    public static void main(String[] args) {
        //todo this for files part
        ReadWriteFile readWriteFile = new ReadWriteFile();
        readWriteFile.writeToFile("Osama M. Al-Dasoqi", 11611035, "IT" , 89);
        
        //todo this for thread part
        System.out.println("this is thread and async method");
        ThreadAsync threadAsync = new ThreadAsync();
        threadAsync.sumThread(10, 10).start();
        threadAsync.divThread(10, 10).start();
        threadAsync.multiThread(10, 10).start();
        threadAsync.subThread(10, 10).start();
    }
    
}
