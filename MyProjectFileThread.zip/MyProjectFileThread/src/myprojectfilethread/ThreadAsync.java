/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myprojectfilethread;

import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Click
 */
public class ThreadAsync {

    public ThreadAsync() {

    }

    public Thread sumThread(int numOne, int numTwo) {
        Thread thread = new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    sleep(1000);
                    int result = numOne + numTwo;
                    System.out.println("" + result);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ThreadAsync.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        };
        return thread;
    }

    public Thread subThread(int numOne, int numTwo) {
        Thread thread = new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    sleep(2000);
                    int result = numOne - numTwo;
                    System.out.println("" + result);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ThreadAsync.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        };
        return thread;
    }

    public Thread divThread(int numOne, int numTwo) {
        Thread thread = new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    sleep(3000);
                    int result = numOne / numTwo;
                    System.out.println("" + result);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ThreadAsync.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        };
        return thread;
    }

    public Thread multiThread(int numOne, int numTwo) {
        Thread thread = new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    sleep(4000);
                    int result = numOne * numTwo;
                    System.out.println("" + result);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ThreadAsync.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        };
        return thread;
    }
}
