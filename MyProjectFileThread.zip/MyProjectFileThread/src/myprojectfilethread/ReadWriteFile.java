/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myprojectfilethread;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Click
 */
public class ReadWriteFile {

    final private String fileName = "MyFile.txt";

    public ReadWriteFile() {
        createFile();
    }

    private void createFile() {
        try {
            File myObj = new File(fileName);
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred." + " " + e.getMessage());
        }
    }

    public void writeToFile(String fullName, int universityId, String colleage, int avg) {
        try {
            FileWriter myWriter = new FileWriter(fileName);
            myWriter.write("My Full Name is : " + fullName + "\n");
            myWriter.write("My universityId is : " + universityId + "\n");
            myWriter.write("My colleage is : " + colleage + "\n");
            myWriter.write("My avg is : " + avg + "\n");
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
            readFromFile();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    private void readFromFile() {
        String allData = "";
        try {
            File myObj = new File(fileName);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                System.out.println(data);
                allData += data + "\n";
            }
            myReader.close();
            JOptionPane.showMessageDialog(null, "This is my data 🤩 \n" + "" + allData);

        } catch (FileNotFoundException e) {
            System.out.println("An error occurred." + " " + e.getMessage());
        }
    }//end

}
